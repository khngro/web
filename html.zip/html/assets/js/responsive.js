document.querySelector(".burger").addEventListener("click", () => {
    document.querySelector(".container").classList.toggle("active");
});